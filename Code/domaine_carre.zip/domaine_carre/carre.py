import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.tri as tri
from datetime import datetime
import elements_finis as ef


def init_maillage_carre_pyth(D=10, exp2=6):
    tria = tri.Triangulation([0, D, 0, D], [0, D, D, 0])
    refiner = tri.UniformTriRefiner(tria)
    tria = refiner.refine_triangulation(subdiv=exp2)
    triangles = tria.triangles
    points = np.zeros((len(tria.x), 2))
    labels = np.zeros((len(tria.x)), dtype=np.int64)
    points[:, 0] = tria.x
    points[:, 1] = tria.y
    for k in range(len(tria.x)):
        if tria.x[k] == D or tria.y[k] == 0 or tria.y[k] == D:
            labels[k] = 1
        else:
            labels[k] = 0
    return triangles, points, labels


def carre_pyth(u1=-1, D=10, exp2=6):
    label1 = 1
    cond_lim = [[label1, u1]]
    print('Paramètres')
    print(
        f'D={D:.2f}, u1={u1:.2f}')
    print(
        f'Construction du maillage (nombre de noeuds = {(2**(exp2)+1)**2:d})')
    triangles, points, labels = init_maillage_carre_pyth(D, exp2)

    start = datetime.now()
    def a(x, y): return 1
    def f(x, y): return ((x-D/2)**2+(y-D/2)**2)/10
    sol_0 = ef.solve_edp(triangles, points, labels, a, f, cond_lim)
    end = datetime.now()
    print(f'Durée pour solve_edp :  {end - start} (hh:mm:ss.ms)')

    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.title('Maillage Python')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir = np.where(labels == 1)[0]
    sol_1 = u1*np.ones(len(cond_dir))
    sol = np.concatenate((sol_0, sol_1))
    trace_points = np.concatenate((inconnus, cond_dir))

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[trace_points, 0], points[trace_points, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  D={D:.2f}, u1={u1:.2f}')

    plt.show()


def init_maillage_carre_matl():
    print('Récupération du maillage')
    points = pd.read_csv('nodes.csv').values
    triangles = pd.read_csv('elements.csv').values-1
    print('Récupération des labels')
    labels = pd.read_csv('labels.csv').values.flatten()
    return triangles, points, labels


def carre_matl():
    params = pd.read_csv('params.csv').values.flatten()
    D = params[0]
    u1 = params[1]
    label1 = 1
    cond_lim = [[label1, u1]]
    print('Paramètres')
    print(
        f'D={D:.2f}, u1={u1:.2f}')

    print('Récupération de la solution')
    sol_matl = pd.read_csv('solution.csv').values.flatten()

    print('Construction du maillage')
    triangles, points, labels = init_maillage_carre_matl()

    start = datetime.now()
    def a(x, y): return 1
    def f(x, y): return ((x-D/2)**2+(y-D/2)**2)/10
    sol_0 = ef.solve_edp(triangles, points, labels, a, f, cond_lim)
    end = datetime.now()
    print(f'Durée pour solve_edp :  {end - start} (hh:mm:ss.ms)')

    print('Tracé des solutions pour comparaison')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.title('Maillage Matlab')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    sol = np.zeros(sol_matl.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0], points[:, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  D={D:.2f}, u1={u1:.2f}')

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0],
               points[:, 1], sol-sol_matl, s=1)
    ax.set_title(
        f'Erreur max = {np.max(np.abs((sol-sol_matl))):.2e} (Python vs. Matlab)')
    plt.show()
