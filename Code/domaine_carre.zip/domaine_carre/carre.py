import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay
import elements_finis as ef


def init_maillage_carre_pyth(N=101, D=10):
    h = D/(N-1)
    xl = np.arange(0, D+h, h)
    yl = np.arange(0, D+h, h)
    points = np.empty((0, 2))
    labels = np.empty((0), dtype=np.int64)

    for m in range(N):
        for n in range(N):
            x = xl[m]
            y = yl[n]
            points = np.append(points, [[x, y]], axis=0)
            if m == N-1 or n == 0 or n == N-1:
                labels = np.append(labels, 1)
            else:
                labels = np.append(labels, 0)

    tri = Delaunay(points)
    triangles = tri.simplices
    return triangles, points, labels


def carre_pyth(a=1, f=1, u1=2, N=101, D=10):
    print('Paramètres')
    print(
        f'D={D:.2f}, u1={u1:.2f}, a={a:.2f}, f={f:.2f}')
    print('Construction du maillage')
    triangles, points, labels = init_maillage_carre_pyth(N, D)

    sol_0 = ef.solve_edp(triangles, points, labels, a, f, [[1, u1]])

    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.title('Maillage Python')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir = np.where(labels == 1)[0]
    sol_1 = u1*np.ones(len(cond_dir))
    sol = np.concatenate((sol_0, sol_1))
    trace_points = np.concatenate((inconnus, cond_dir))

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[trace_points, 0], points[trace_points, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  D={D:.2f}, u1={u1:.2f}, a={a:.2f}, f={f:.2f}')

    plt.show()


def init_maillage_carre_matl():
    print('Récupération du maillage')
    points = pd.read_csv('nodes.csv').values
    triangles = pd.read_csv('elements.csv').values-1
    print('Récupération des labels')
    labels = pd.read_csv('labels.csv').values.flatten()
    return triangles, points, labels


def carre_matl():
    params = pd.read_csv('params.csv').values.flatten()
    D = params[0]
    u1 = params[1]
    a = params[2]
    f = params[3]
    label1 = 1
    cond_lim = [[label1, u1]]
    print('Paramètres')
    print(
        f'D={D:.2f}, u1={u1:.2f}, a={a:.2f}, f={f:.2f}')

    print('Récupération de la solution')
    sol_matl = pd.read_csv('solution.csv').values.flatten()

    print('Construction du maillage')
    triangles, points, labels = init_maillage_carre_matl()

    sol_0 = ef.solve_edp(triangles, points, labels, a, f, cond_lim)

    print('Tracé des solutions pour comparaison')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.title('Maillage Matlab')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    sol = np.zeros(sol_matl.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0], points[:, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  D={D:.2f}, u1={u1:.2f}, a={a:.2f}, f={f:.2f}')

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0],
               points[:, 1], sol-sol_matl, s=1)
    ax.set_title(
        f'Erreur max = {np.max(np.abs((sol-sol_matl))):.2e} (Python vs. Matlab)')
    plt.show()
