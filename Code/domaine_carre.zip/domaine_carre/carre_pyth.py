import carre
carre.carre_pyth()
