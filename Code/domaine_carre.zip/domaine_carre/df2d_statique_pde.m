function df2d_statique_pde(a,f,u1,D,Hmax)
if nargin==0
    a=1;f=1;u1=-1;D=10;Hmax=D/100;
end
close all
% Rectangle is code 3, 4 sides, followed by x-coordinates and then y-coordinates
R1 = [3,4,0,D,D,0,0,0,D,D]';
geom = R1;
% Names for the two geometric objects
ns = (char('R1'))';
% Set formula
sf = 'R1';
% Create geometry
geo = decsg(geom,sf,ns);
% Create geometry model
model = createpde;
% Include the geometry in the model and view the geometry
geometryFromEdges(model,geo);

% -laplacien(u)+a*u=f
specifyCoefficients(model,'m',0,...
                          'd',0,...
                          'c',1,...
                          'a',a,...
                          'f',f);
mesh = generateMesh(model,'Hmax',Hmax,'GeometricOrder','linear');

applyBoundaryCondition(model,'dirichlet','edge',[1 2 3],'u',u1);
applyBoundaryCondition(model,'neumann','edge',4,'g',0);

results = solvepde(model);
u = results.NodalSolution;

figure,pdeplot(model,'XYData',u,'ZData',u)
colormap(jet)
grid on
xlabel('x')
ylabel('y')
drawnow

labels=zeros(size(u));
labels(mesh.Nodes(1,:)==D) = 1;
labels(mesh.Nodes(2,:)==D) = 1;
labels(mesh.Nodes(2,:)==0) = 1;

params=[D u1 a f];

writetable(table(mesh.Nodes'),'nodes.csv')
writetable(table(mesh.Elements'),'elements.csv')
writetable(table(u),'solution.csv')
writetable(table(labels),'labels.csv')
writetable(table(params),'params.csv')