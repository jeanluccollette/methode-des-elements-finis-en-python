function carre_matl(u1,D,Hmax)
if nargin==0
    u1=-1;D=10;Hmax=D/100;
end
close all
% Rectangle is code 3, 4 sides, followed by x-coordinates and then y-coordinates
R1 = [3,4,0,D,D,0,0,0,D,D]';
geom = R1;
% Names for the two geometric objects
ns = (char('R1'))';
% Set formula
sf = 'R1';
% Create geometry
geo = decsg(geom,sf,ns);
% Create geometry model
model = createpde;
% Include the geometry in the model and view the geometry
geometryFromEdges(model,geo);

figure,pdegplot(model,'EdgeLabels','on'),drawnow

% -laplacien(u)+a*u=f
specifyCoefficients(model,'m',0,...
                          'd',0,...
                          'c',1,...
                          'a',@(loc,stat) 1+0*loc.x,...
                          'f',@(loc,stat) ((loc.x-D/2).^2+(loc.y-D/2).^2)/10);
mesh = generateMesh(model,'Hmax',Hmax,'GeometricOrder','linear');

applyBoundaryCondition(model,'dirichlet','edge',[1 2 3],'u',u1);
applyBoundaryCondition(model,'neumann','edge',4,'g',0);

results = solvepde(model);
u_n = results.NodalSolution;
disp(length(u_n))

figure,pdeplot(model)
drawnow

figure,pdeplot(model,'XYData',u_n,'ZData',u_n)
colormap(jet)
grid on
xlabel('x')
ylabel('y')
drawnow

labels=zeros(size(u_n));
labels(mesh.Nodes(1,:)==D) = 1;
labels(mesh.Nodes(2,:)==D) = 1;
% labels(mesh.Nodes(1,:)==0) = 1;
labels(mesh.Nodes(2,:)==0) = 1;

params=[D u1];

writetable(table(mesh.Nodes'),'nodes.csv')
writetable(table(mesh.Elements'),'elements.csv')
writetable(table(u_n),'solution.csv')
writetable(table(labels),'labels.csv')
writetable(table(params),'params.csv')