import coaxial_maillage_gmsh
coaxial_maillage_gmsh.coaxial_gmsh(r1=0.2,r2=1,u1=12,u2=10,h=0.02)