import coaxial_maillage_gmsh
coaxial_maillage_gmsh.coaxial_gmsh(
    r1=0.2, r2=1, u1=12, u2=10, label1=10, label2=20, h=0.04)
