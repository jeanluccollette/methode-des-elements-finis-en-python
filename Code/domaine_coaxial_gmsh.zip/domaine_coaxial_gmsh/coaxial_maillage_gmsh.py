import numpy as np
import math
import matplotlib.pyplot as plt
from datetime import datetime
import gmsh
import elements_finis as ef


def init_maillage_coaxial_gmsh(r1=0.2, r2=1.0, h=0.05):
    gmsh.initialize()
    model = gmsh.model
    center = model.geo.addPoint(0, 0, 0, h, 10)
    points = []
    for j in range(3):
        points.append(model.geo.addPoint(r1*math.cos(2*math.pi*j/3),
                                         r1*math.sin(2*math.pi*j/3), 0, h))
    for j in range(3):
        points.append(model.geo.addPoint(r2*math.cos(2*math.pi*j/3),
                                         r2*math.sin(2*math.pi*j/3), 0, h))
    print(points)
    lines1 = []
    lines2 = []
    for j in range(3):
        lines1.append(model.geo.addCircleArc(
            points[j], center, points[(j+1) % 3]))
    for j in range(3):
        lines2.append(model.geo.addCircleArc(
            points[3+j], center, points[3+(j+1) % 3]))
    print(lines1)
    print(lines2)
    # Curveloop and Surface
    c1 = model.geo.addCurveLoop([1, 2, 3])
    c2 = model.geo.addCurveLoop([4, 5, 6])
    model.geo.addPlaneSurface([c1, c2])
    gmsh.model.geo.synchronize()
    # Mesh (2D)
    model.mesh.generate(2)
    _, nodeCoords, _ = gmsh.model.mesh.getNodes()
    _, _, nodeTags = gmsh.model.mesh.getElements()
    points = np.reshape(nodeCoords, (int(len(nodeCoords)/3), 3))
    labels = np.zeros(points.shape[0])
    labels[np.abs(points[:, 0]**2+points[:, 1]**2-r1**2) < 1e-10] = 1
    labels[np.abs(points[:, 0]**2+points[:, 1]**2-r2**2) < 1e-10] = 2
    labels[0] = -1
    triangles = np.reshape(nodeTags[1], (int(len(nodeTags[1])/3), 3))-1
    gmsh.finalize()
    return triangles, points, labels


def coaxial_gmsh(r1=0.2, r2=1, u1=12, u2=10, h=0.1):
    label1 = 1
    label2 = 2
    cond_lim = [[label1, u1], [label2, u2]]
    print('Paramètres')
    print(
        f'r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}')
    print(f'Construction du maillage avec h={h:.2f}')
    triangles, points, labels = init_maillage_coaxial_gmsh(r1, r2, h)

    start = datetime.now()
    def a(x, y): return 2
    def f(x, y): return 10*x
    sol_0 = ef.solve_edp(triangles, points, labels, a, f, cond_lim)
    end = datetime.now()
    print(f'Durée pour solve_edp :  {end - start} (hh:mm:ss.ms)')

    print('Tracé de la solution')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.plot(points[labels == 2, 0], points[labels == 2, 1], 'go', ms=2)
    plt.title(f'Maillage Python avec gmsh (h={h:.2f})')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    cond_dir_2 = np.where(labels == 2)[0]

    sol = np.zeros(labels.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1
    sol[cond_dir_2] = u2

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[labels != -1, 0],
               points[labels != -1, 1], sol[labels != -1], s=1)
    ax.set_title(
        f'Solution Python  r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}')

    plt.show()
