import carre_maillage_gmsh
carre_maillage_gmsh.carre_gmsh(u1=-1, D=10, lc=0.1)
