import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import elements_finis as ef
import gmsh


def init_maillage_carre_gmsh(D=10, h=0.1, label1=1):
    gmsh.initialize()
    gmsh.model.add("t1")
    gmsh.model.geo.addPoint(0, 0, 0, h, 1)
    gmsh.model.geo.addPoint(D, 0, 0, h, 2)
    gmsh.model.geo.addPoint(D, D, 0, h, 3)
    gmsh.model.geo.addPoint(0, D, 0, h, 4)
    gmsh.model.geo.addLine(1, 2, 1)
    gmsh.model.geo.addLine(2, 3, 2)
    gmsh.model.geo.addLine(3, 4, 3)
    gmsh.model.geo.addLine(4, 1, 4)
    gmsh.model.geo.addCurveLoop([1, 2, 3, 4], 10)
    gmsh.model.geo.addPlaneSurface([10], 1)
    gmsh.model.geo.synchronize()
    gmsh.model.mesh.generate(2)
    _, nodeCoords, _ = gmsh.model.mesh.getNodes()
    _, _, nodeTags = gmsh.model.mesh.getElements()
    nodes = np.reshape(nodeCoords, (int(len(nodeCoords)/3), 3))
    points = nodes[:, 0:2]
    triangles = np.reshape(nodeTags[1], (int(len(nodeTags[1])/3), 3))-1
    labels = np.zeros(points.shape[0])
    # labels[points[:,0]==0]=1
    labels[points[:, 0] == D] = label1
    labels[points[:, 1] == 0] = label1
    labels[points[:, 1] == D] = label1
    gmsh.finalize()
    return triangles, points, labels


def carre_gmsh(u1=-1, label1=1, D=10, h=0.1):
    cond_lim = [[label1, u1]]
    print('Paramètres')
    print(
        f'D={D:.2f}, u1={u1:.2f}')
    print(f'Construction du maillage avec h={h:.2f}')
    triangles, points, labels = init_maillage_carre_gmsh(D, h, label1)

    start = datetime.now()
    def a(x, y): return 1
    def f(x, y): return ((x-D/2)**2+(y-D/2)**2)/10
    sol_0 = ef.solve_edp(triangles, points, labels, a, f, cond_lim)
    end = datetime.now()
    print(f'Durée pour solve_edp :  {end - start} (hh:mm:ss.ms)')

    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == label1, 0],
             points[labels == label1, 1], 'ro', ms=2)
    plt.title(f'Maillage Python avec gmsh (h={h:.2f})')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir = np.where(labels == label1)[0]
    sol_1 = u1*np.ones(len(cond_dir))
    sol = np.concatenate((sol_0, sol_1))
    trace_points = np.concatenate((inconnus, cond_dir))

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[trace_points, 0], points[trace_points, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  D={D:.2f}, u1={u1:.2f}')

    plt.show()
