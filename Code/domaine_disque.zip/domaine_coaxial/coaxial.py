import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay
import elements_finis as ef


def init_maillage_coaxial_matl():
    print('Récupération du maillage')
    points = pd.read_csv('nodes.csv').values
    triangles = pd.read_csv('elements.csv').values-1
    print('Récupération des labels')
    labels = pd.read_csv('labels.csv').values.flatten()
    return triangles, points, labels


def coaxial_matl():
    params = pd.read_csv('params.csv').values.flatten()
    r1 = params[0]
    r2 = params[1]
    u1 = params[2]
    u2 = params[3]
    a = params[4]
    f = params[5]
    label1 = 1
    label2 = 2
    cond_lim = [[label1, u1], [label2, u2]]
    print('Paramètres')
    print(
        f'r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')

    print('Récupération de la solution')
    sol_matl = pd.read_csv('solution.csv').values.flatten()

    print('Construction du maillage')
    triangles, points, labels = init_maillage_coaxial_matl()

    sol_0 = ef.solve_edp(triangles, points, labels, a *
                         np.ones(labels.shape), f*np.ones(labels.shape), cond_lim)

    print('Tracé des solutions pour comparaison')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.plot(points[labels == 2, 0], points[labels == 2, 1], 'go', ms=2)
    plt.title('Maillage Matlab')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    cond_dir_2 = np.where(labels == 2)[0]

    sol = np.zeros(labels.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1
    sol[cond_dir_2] = u2

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0], points[:, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0],
               points[:, 1], sol-sol_matl, s=1)
    ax.set_title(
        f'Erreur max = {np.max(np.abs((sol-sol_matl))):.2e} (Python vs. Matlab)')
    plt.show()


def init_maillage_coaxial_circ(r1=0.2, r2=1.0):
    n_angles = 50
    n_rayons = 30
    r = np.linspace(r1, r2, n_rayons)

    angles = np.linspace(0, 2 * np.pi, n_angles, endpoint=False)
    angles = np.repeat(angles[..., np.newaxis], n_rayons, axis=1)
    angles[:, 1::2] += np.pi / n_angles

    x = (r*np.cos(angles)).flatten()
    y = (r*np.sin(angles)).flatten()

    points = np.empty((0, 2))
    labels = np.empty((0), dtype=np.int64)
    for k in range(x.shape[0]):
        points = np.append(points, [[x[k], y[k]]], axis=0)
        if np.abs(x[k]**2+y[k]**2 - (r1**2)) < 1e-10:
            labels = np.append(labels, 1)
        elif np.abs(x[k]**2+y[k]**2 - (r2**2)) < 1e-10:
            labels = np.append(labels, 2)
        else:
            labels = np.append(labels, 0)

    points = np.append(points, [[0, 0]], axis=0)
    labels = np.append(labels, -1)

    # Perform Delaunay triangulation
    tri = Delaunay(points)

    triangles = tri.simplices
    index_tri = np.where(np.any(triangles == points.shape[0]-1, axis=1))[0]
    triangles = np.delete(triangles, index_tri, axis=0)
    points = np.delete(points, -1, axis=0)
    labels = np.delete(labels, -1)

    return triangles, points, labels


def coaxial_circ():
    r1 = 0.2
    r2 = 1.0
    u1 = 12
    u2 = 10
    a = 10.0
    f = -10.0
    label1 = 1
    label2 = 2
    cond_lim = [[label1, u1], [label2, u2]]
    print('Paramètres')
    print(
        f'r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')

    print('Construction du maillage')
    triangles, points, labels = init_maillage_coaxial_circ()

    sol_0 = ef.solve_edp(triangles, points, labels, a *
                         np.ones(labels.shape), f*np.ones(labels.shape), cond_lim)

    print('Tracé de la solution')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.plot(points[labels == 2, 0], points[labels == 2, 1], 'go', ms=2)
    plt.title('Maillage Python')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    cond_dir_2 = np.where(labels == 2)[0]

    sol = np.zeros(labels.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1
    sol[cond_dir_2] = u2

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0], points[:, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')

    plt.show()


def init_maillage_coaxial_hexa(r1=0.2, r2=1.0):
    h = 0.05
    xmin = -1
    xmax = 1+h
    ymin = -25*h*np.sqrt(3)/2
    ymax = 26*h*np.sqrt(3)/2
    xl = np.arange(xmin, xmax, h)
    yl = np.arange(ymin, ymax, h*np.sqrt(3)/2)
    a1cer = np.arange(0, 2*np.pi, 2*np.pi/32)
    a2cer = np.arange(0, 2*np.pi, 2*np.pi/100)

    points = np.empty((0, 2))
    labels = np.empty((0), dtype=np.int64)
    for a1 in a1cer:
        points = np.append(points, [[r1*np.cos(a1), r1*np.sin(a1)]], axis=0)
        labels = np.append(labels, 1)
    for a2 in a2cer:
        points = np.append(points, [[r2*np.cos(a2), r2*np.sin(a2)]], axis=0)
        labels = np.append(labels, 2)

    ind = 0
    for y in yl:
        for x in xl:
            if ind % 2 == 0:
                rexp2 = x**2+y**2
                if rexp2 > r1**2 and rexp2 < r2**2:
                    points = np.append(points, [[x, y]], axis=0)
                    labels = np.append(labels, 0)
            else:
                rexp2 = (x+h/2)**2+y**2
                if rexp2 > r1**2 and rexp2 < r2**2:
                    points = np.append(points, [[x+h/2, y]], axis=0)
                    labels = np.append(labels, 0)
        ind = ind+1

    for noeud in range(points.shape[0]):
        if labels[noeud] == 0:
            liste_noeuds = np.arange(points.shape[0])
            liste_noeuds = np.delete(liste_noeuds, noeud)
            if any(np.sqrt((points[liste_noeuds, 0]-points[noeud, 0])**2+(points[liste_noeuds, 1]-points[noeud, 1])**2) < h/3):
                labels[noeud] = -2
    points = np.delete(points, np.where(labels == -2)[0], axis=0)
    labels = np.delete(labels, np.where(labels == -2)[0])

    points = np.append(points, [[0, 0]], axis=0)
    labels = np.append(labels, -1)

    # Perform Delaunay triangulation
    tri = Delaunay(points)

    triangles = tri.simplices
    index_tri = np.where(np.any(triangles == points.shape[0]-1, axis=1))[0]
    triangles = np.delete(triangles, index_tri, axis=0)
    points = np.delete(points, -1, axis=0)
    labels = np.delete(labels, -1)

    return triangles, points, labels


def coaxial_hexa():
    r1 = 0.2
    r2 = 1.0
    u1 = 12
    u2 = 10
    a = 10.0
    f = -10.0
    label1 = 1
    label2 = 2
    cond_lim = [[label1, u1], [label2, u2]]
    print('Paramètres')
    print(
        f'r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')
    print('Construction du maillage')
    triangles, points, labels = init_maillage_coaxial_hexa()

    sol_0 = ef.solve_edp(triangles, points, labels, a *
                         np.ones(labels.shape), f*np.ones(labels.shape), cond_lim)

    print('Tracé de la solution')
    plt.figure(figsize=(8, 6))
    plt.triplot(points[:, 0], points[:, 1],
                triangles, lw=0.5, ms=100)
    plt.plot(points[labels == 0, 0], points[labels == 0, 1], 'bo', ms=1)
    plt.plot(points[labels == 1, 0], points[labels == 1, 1], 'ro', ms=2)
    plt.plot(points[labels == 2, 0], points[labels == 2, 1], 'go', ms=2)
    plt.title('Maillage Python')
    plt.axis('equal')

    inconnus = np.where(labels == 0)[0]
    cond_dir_1 = np.where(labels == 1)[0]
    cond_dir_2 = np.where(labels == 2)[0]

    sol = np.zeros(labels.shape)
    sol[inconnus] = sol_0
    sol[cond_dir_1] = u1
    sol[cond_dir_2] = u2

    ax = plt.figure(figsize=(8, 6)).add_subplot(projection='3d')
    ax.scatter(points[:, 0], points[:, 1], sol, s=1)
    ax.set_title(
        f'Solution Python  r1={r1:.2f}, r2={r2:.2f}, u1={u1:.2f}, u2={u2:.2f}, a={a:.2f}, f={f:.2f}')

    plt.show()
